package com.accenture.lkm;

import com.accenture.lkm.p1.Sample;

public class Hello extends Object{

	public Hello()
	{
		
	}
	public static void main(String[] args) 
	{
		Sample s=new Sample();
		System.out.println("Hello");
	}
	
	//Hello   com.accenture.lkm
	//String  java.lang
	//System  java.lang
	//java.lang package is a default package

}
