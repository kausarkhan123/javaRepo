package com.accenture.lkm.p1;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class ExceptionDemoWithFinally {

	public static void main(String[] args) throws IOException 
	{
		FileReader r=null;
		try
		{

			System.out.println("in try");
			r=new FileReader("c://users//kausar.khan//newFile.txt"); //FileNotFoundException

			int c=r.read();
			//sensitive code
			
		}
		catch(FileNotFoundException e)
		{
			System.out.println("Exception Handled: "+e);
			e.printStackTrace();
		}
		finally
		{
			System.out.println("Finally block");
		}
		
		r.close(); //exception occurred here ..... r=null r.close(); --> nullpointerException
		System.out.println("nothing");
		
	
	}

}
