package com.accenture.lkm;

public class Employee {
private int empId;
private String empName;
private Adhaar adhaar;
Employee(int empId,String empName,Adhaar adhaar)
{
	this.empId=empId;
	this.empName=empName;
	this.adhaar=adhaar;
}
public int getEmpId() {
	return empId;
}
public String getEmpName() {
	return empName;
}
public Adhaar getAdhaar() {
	return adhaar;
}

}
