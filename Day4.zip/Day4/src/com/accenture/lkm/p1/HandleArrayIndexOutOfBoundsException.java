package com.accenture.lkm.p1;

import java.util.Scanner;

public class HandleArrayIndexOutOfBoundsException {

	public static void main(String[] args) 
	{
		int arr[]= {10,10,50,7,9,100,3,500,20,34,12,111,121}; //13 elements
		Scanner sc=new Scanner(System.in);
		System.out.println("Please enter your range");
		int lowerBound=0,upperBound=0;
		lowerBound=sc.nextInt(); 
		upperBound=sc.nextInt();
		
		try //to place sensitive code
		{
		//sensitive
		for(int i=lowerBound; i<upperBound;i++)
		{
			System.out.print(" "+arr[i]); //sensitive code
		}
	
		}
		catch(ArrayIndexOutOfBoundsException e)
		{
			//Throwable(printStackTrace())->Exception-->ArrayIndexOutOfBoundsException
			e.printStackTrace(); //to get detailed info about exception
			System.out.println(e);
			//You should log errors here
			
		}
			
		System.out.println("End of program");
		
	}

}
