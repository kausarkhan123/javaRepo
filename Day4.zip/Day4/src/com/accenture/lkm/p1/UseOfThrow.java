package com.accenture.lkm.p1;

import java.util.Scanner;

public class UseOfThrow {

	public static void main(String[] args)
	{
		int salary=0;
		int bonus=0;
		int tot=0;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter salary and bonus");
		salary=sc.nextInt();
		bonus=sc.nextInt();
		tot=salary+bonus; //sensitive code
		try
		{
		if(tot>50000) //checked 
		{                              // message             //message2
			throw new UserException("Too much amount","CUSTOM EXCEPTION"); //forcefully, raising exception
		}
		}
		catch(UserException e)
		{
			System.out.println("in catch: "+e);
			e.printStackTrace();
			e.getMessage();
		}
		System.out.println("Total Salary: "+tot);
		System.out.println("End of program: ");
		
	}

}
