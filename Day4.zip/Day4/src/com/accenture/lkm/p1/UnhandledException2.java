package com.accenture.lkm.p1;

import java.util.Scanner;

public class UnhandledException2 {

	public static void main(String[] args)
	{            // 0  1  2  3 4     ...           11   12
		int arr[]= {10,10,50,7,9,100,3,500,20,34,12,111,121}; //13 elements
		Scanner sc=new Scanner(System.in);
		System.out.println("Please enter your range");
		int lowerBound=0,upperBound;
		lowerBound=sc.nextInt(); //sensitive
		upperBound=sc.nextInt(); //sensitive code
		for(int i=lowerBound; i<upperBound;i++)
		{
			System.out.print(" "+arr[i]);
		}
		System.out.println("End of program");
		
		
	}

}
