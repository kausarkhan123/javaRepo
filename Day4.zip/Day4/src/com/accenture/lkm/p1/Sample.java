package com.accenture.lkm.p1;

public class Sample {

}
