package com.accenture.lkm;

public class Test {

	public static void main(String[] args)
	{
		Adhaar a=new Adhaar();
		a.setEnrollmentNo(100023);
		a.setAddress("Agra");
		a.setName("Amit Kumar");
		
		Employee e=new Employee(1,a.getName(),a);
		System.out.println("Details: "+e.getEmpId()+" "+e.getEmpName());
		Adhaar ad=e.getAdhaar();
		System.out.println("Adhaar Details: "+ad.getEnrollmentNo()+" "+ad.getName()+" "+ad.getAddress());
	}

}
