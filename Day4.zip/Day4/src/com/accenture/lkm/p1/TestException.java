package com.accenture.lkm.p1;

import java.util.Scanner;

public class TestException {

	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		int num=0,div=0,t=0;
		System.out.println("Provide two values to divide");
		num=sc.nextInt();
		div=sc.nextInt();
		t=num/div;
		System.out.println("Result is: "+t);
		System.out.println("End of program");
		
	}

}
