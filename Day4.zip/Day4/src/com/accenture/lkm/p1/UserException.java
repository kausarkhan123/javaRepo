package com.accenture.lkm.p1;

public class UserException extends Exception
{
	//Object->Throwable->Exception->UserException
private String message2;
public UserException(String message,String message2)
{
	super(message); //too much amount
	this.message2=message2; //CUSTOM EXCEPTION
}
void displayErrorMessage()
{
	System.out.println("Custom exception generated");
}
@Override
public String toString() 
{
	
	return "UserException Handled: "+getMessage()+ " "+ message2 ;
	//predefined method of Exception class -getMessage()
}

}
