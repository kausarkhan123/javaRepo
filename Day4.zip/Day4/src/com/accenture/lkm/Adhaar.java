package com.accenture.lkm;

public class Adhaar 
{
private int enrollmentNo;
private String name;
private String address;
public int getEnrollmentNo() {
	return enrollmentNo;
}
public void setEnrollmentNo(int enrollmentNo) {
	this.enrollmentNo = enrollmentNo;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getAddress() {
	return address;
}
public void setAddress(String address) {
	this.address = address;
}

}
