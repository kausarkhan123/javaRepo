package com.accenture.lkm;

public class TestAggregation {

	public static void main(String[] args) 
	{
		//Aggregation
		Address ad=new Address();
		ad.setCity("LKO");
		ad.setAddressId(226001);
		ad.setState("UP");
		
		User user=new User(1001,"Amit","amit123",ad);
		//user.setUserId(1001);
		//user.setUserName("Ravi");
		//user.setPassword("ravi123");
		//user.setAddress(ad);
		
		System.out.println("User Details: "+user.getUserId()+" "+user.getUserName()+" "+user.getPassword());
		if(user.getAddress()!=null)
		{
		System.out.println("Address details: "+user.getAddress().getCity()+" "+user.getAddress().getState());
		}
		}

}
